<?php

namespace App\Services;

use App\Exceptions\AffiliateCreateException;
use App\Mail\AffiliateCreated;
use App\Models\Affiliate;
use App\Models\Merchant;
use App\Models\Order;
use App\Models\User;
use Illuminate\Support\Facades\Mail;

class AffiliateService
{
    public function __construct(
        protected ApiService $apiService
    ) {
    }

    /**
     * Create a new affiliate for the merchant with the given commission rate.
     *
     * @param  Merchant $merchant
     * @param  string $email
     * @param  string $name
     * @param  float $commissionRate
     * @return Affiliate
     */
    public function register(Merchant $merchant, string $email, string $name, float $commissionRate): Affiliate
    {

        $user = new User();
        $user->name = $name;
        $user->email = $email;
        $user->password = Hash::make($name);
        $user->type = User::TYPE_AFFILIATE;
        $user->save();

        $discountCode = $this->apiService->createDiscountCode($merchant);

        $affiliate = new Affiliate();
        $affiliate->user_id =  $user->id;
        $affiliate->merchant_id =  $merchant->id;
        $affiliate->commission_rate = $commissionRate;
        $affiliate->discount_code = $discountCode;
        if ($affiliate->save()) {
            // Send email notification for affiliate creation
            $this->sendAffiliateCreatedEmail($affiliate);
            return $affiliate;
        }

        throw new AffiliateCreateException('Failed to create affiliate.');
    }

    protected function sendAffiliateCreatedEmail(Affiliate $affiliate)
    {
        try {
            Mail::to($affiliate->user->email)->send(new AffiliateCreated($affiliate));
        } catch (\Exception $exception) {

            throw new AffiliateCreateException('Failed to send affiliate creation email.');
        }
    }
}
